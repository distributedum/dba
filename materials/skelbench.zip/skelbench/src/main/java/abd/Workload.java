package abd;
import java.sql.*;
import java.util.*;

public class Workload {

    private static final Random random = new Random();

    public static void populate(Random rand, Connection c, int scale) throws Exception {
        List<Util.ProductInfo> productsDataset = Util.getProductsDataset();
        Collections.shuffle(productsDataset);
        String extraData = Util.randomString(1000);

        // Create schema
        Statement s = c.createStatement();
        s.executeUpdate("create table if not exists client (id int, name varchar, address varchar, data text)");
        s.executeUpdate("create table if not exists product (id int, description varchar, price decimal(10, 2), ref varchar, data text)");
        s.executeUpdate("create table if not exists invoice (id serial, productid int, clientid int, price decimal(10, 2), data text)");
        // Delete old data
        s.executeUpdate("truncate client");
        s.executeUpdate("truncate product");
        s.executeUpdate("truncate invoice");
        s.close();

        // Insert data
        PreparedStatement insertClient = c.prepareStatement("insert into client values (?, ?, ?, ?)");
        PreparedStatement insertProduct = c.prepareStatement("insert into product values (?, ?, ?, ?, ?)");
        c.setAutoCommit(false); // Autocommit off to execute inserts in a single transaction to reduce overhead
        for (int i = 0; i < Math.pow(2, scale); i++) {
            insertClient.setInt(1, i); // id
            insertClient.setString(2, "client-" + i); // name
            insertClient.setString(3, "address-" + i); // address
            insertClient.setString(4, extraData); // data
            insertClient.addBatch();

            Util.ProductInfo product = productsDataset.get(i % productsDataset.size());
            insertProduct.setInt(1, i); // id
            insertProduct.setString(2, product.name()); // description
            insertProduct.setDouble(3, product.price()); // price
            insertProduct.setString(4, product.ref()); // ref
            insertProduct.setString(5, extraData); // data
            insertProduct.addBatch();
        }
        insertClient.executeBatch();
        insertProduct.executeBatch();
        c.commit(); // commit must be called manually since autocommit is off

        insertClient.close();
        insertProduct.close();
    }


    private final Random rand;
    private final Connection c;
    final private PreparedStatement getProductPrice;
    final private PreparedStatement addInvoice;
    final private PreparedStatement clientProducts;
    final private PreparedStatement topProducts;
    final private int scale;


    public Workload(Random rand, Connection c, int scale) throws Exception {
        this.rand = rand;
        this.c = c;
        this.scale = scale;

        c.setAutoCommit(false); // autocommit = off to execute operations inside a transaction

        // create prepared statements

        getProductPrice = c.prepareStatement("""
            select price
            from product
            where id = ?
        """);

        addInvoice = c.prepareStatement("""
            insert into invoice (productid, clientid, price, data) values (?, ?, ?, ?)
        """);

        clientProducts = c.prepareStatement("""
            select p.id
            from product p
            join invoice i on i.productid = p.id
            where i.clientid = ?
        """);

        topProducts = c.prepareStatement("""
            select p.id, count(i.id)
            from product p
            join invoice i on i.productid = p.id
            group by p.id
            order by count(i.id) desc
            limit 10
        """);
    }


    private void sell() throws SQLException {
        int clientId = random.nextInt((int) Math.pow(2, scale));
        int productId = random.nextInt((int) Math.pow(2, scale));

        getProductPrice.setInt(1, productId);
        ResultSet rs = getProductPrice.executeQuery();
        rs.next();

        addInvoice.setInt(1, productId);
        addInvoice.setInt(2, clientId);
        addInvoice.setDouble(3, rs.getDouble(1));
        addInvoice.setString(4, Util.randomString(1000));
        addInvoice.executeUpdate(); // executeUpdate when performing writes
        c.commit();
    }


    private List<Integer> account() throws SQLException {
        int clientId = random.nextInt((int) Math.pow(2, scale));
        List<Integer> products = new ArrayList<>();
        clientProducts.setInt(1, clientId);
        ResultSet rs = clientProducts.executeQuery(); // executeQuery when performing reads

        while (rs.next()) {
            products.add(rs.getInt(1));
        }

        c.commit();

        return products;
    }


    private Map<Integer, Integer> top10() throws SQLException {
        Map<Integer, Integer> top = new HashMap<>();
        ResultSet rs = topProducts.executeQuery();

        while (rs.next()) {
            top.put(rs.getInt(1), rs.getInt(2));
        }

        c.commit();

        return top;
    }


    public void transaction() throws Exception {
        int x = rand.nextInt(100);
        if (x <= 50) {
            sell();
        } else if (x <= 75) {
            account();
        } else {
            top10();
        }
    }
}
