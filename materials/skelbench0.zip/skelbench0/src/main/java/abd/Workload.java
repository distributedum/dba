package abd;
import java.sql.*;
import java.util.*;

public class Workload {

    public static void populate(Random rand, Connection c, int scale) throws Exception {
        Statement s = c.createStatement();
        s.executeUpdate("...");
        // ...
    }


    private final Random rand;
    private final Connection c;
    private int scale;


    public Workload(Random rand, Connection c, int scale) throws Exception {
        this.rand = rand;
        this.c = c;
        this.scale = scale;

        this.c.setAutoCommit(false); // autocommit = off to execute operations inside a transaction
    }


    private void sell() throws SQLException {
        // ...
        c.commit();
    }


    private List<Integer> account() throws SQLException {
        // ...
        c.commit();
        return null;
    }


    private Map<Integer, Integer> top10() throws SQLException {
        // ...
        c.commit();
        return null;
    }


    public void transaction() throws Exception {
        // ...
    }
}
