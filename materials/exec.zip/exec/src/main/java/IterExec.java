import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

public class IterExec {

    public static class Proj implements Iterator {
        private final Iterator<List<Object>> in;
        private final int[] cols;

        public Proj(Iterator<List<Object>> in, int[] cols) {
            this.in = in;
            this.cols = cols;
        }

        @Override
        public boolean hasNext() {
            return in.hasNext();
        }

        @Override
        public Object next() {
            var li = in.next();
            var lo = new ArrayList<Object>(cols.length);
            for(var c: cols)
                lo.add(li.get(c));
            return null;
        }
    };

    public static class Sel implements Iterator<List<Object>> {
        private final Iterator<List<Object>> in;
        private final Predicate<List<Object>> pred;
        private List<Object> next;

        public Sel(Iterator<List<Object>> in, Predicate<List<Object>> pred) {
            this.in = in;
            this.pred = pred;
        }

        
        @Override
        public boolean hasNext() {
            while(next == null) {
                if (!in.hasNext())
                    return false;
                next = in.next();
                if (!pred.test(next))
                    next = null;
            }
            return true;
        }

        @Override
        public List<Object> next() {
            try {
                return next;
            } finally {
                next = null;
            }
        }
    }

    public static void main(String[] args) throws Exception {
        List<List<Object>> a = Arrays.asList(
                Arrays.asList(1, "111"),
                Arrays.asList(2, "222"),
                Arrays.asList(3, "333"),
                Arrays.asList(4, "444"),
                Arrays.asList(5, "555")
        );

        var rs = new Proj(new Sel(a.iterator(), (l)->((Integer)l.get(0))>3), new int[]{0});
        while(rs.hasNext())
            System.out.println(rs.next().toString());
    }
}
