import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class MatExec {

    public static List<List<Object>> proj(List<List<Object>> in, int[] cols) {
        var out = new ArrayList<List<Object>>();
        for(var li: in) {
            var lo = new ArrayList<Object>(cols.length);
            for(var c: cols)
                lo.add(li.get(c));
            out.add(lo);
        }
        return out;
    }

    public static List<List<Object>> sel(List<List<Object>> in, Predicate<List<Object>> pred) {
        var out = new ArrayList<List<Object>>();
        for (var li : in) {
            if (pred.test(li))
                out.add(li);
        }
        return out;
    }


    public static void main(String[] args) throws Exception {
        List<List<Object>> a = Arrays.asList(
                Arrays.asList(1, "111"),
                Arrays.asList(2, "222"),
                Arrays.asList(3, "333"),
                Arrays.asList(4, "444"),
                Arrays.asList(5, "555")
        );

        System.out.println(proj(sel(a, (l)->((Integer)l.get(0))>3), new int[]{0}).toString());
    }
}
