#!/bin/bash

# postgres
sudo apt install -y wget ca-certificates
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ `lsb_release -cs`-pgdg main" >> /etc/apt/sources.list.d/pgdg.list'
sudo apt-get update
sudo apt-get install -y postgresql-17
sudo -u postgres psql -c "alter user postgres with password 'postgres'"
sudo sed -i '1ihost    all             all             0.0.0.0/0               md5' /etc/postgresql/17/main/pg_hba.conf
sudo sed -i '1ilocal   all             postgres                                md5' /etc/postgresql/17/main/pg_hba.conf
sudo systemctl restart postgresql
PGPASSWORD=postgres createdb -U postgres testdb

# postgres udfs in python
sudo apt install -y postgresql-plpython3-17 python3-requests

# java
sudo apt install -y maven openjdk-21-jdk-headless
