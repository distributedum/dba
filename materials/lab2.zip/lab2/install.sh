#!/bin/bash

# postgres
sudo apt install -y curl ca-certificates
sudo install -d /usr/share/postgresql-common/pgdg
sudo curl -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc --fail https://www.postgresql.org/media/keys/ACCC4CF8.asc
. /etc/os-release
sudo sh -c "echo 'deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt $VERSION_CODENAME-pgdg main' > /etc/apt/sources.list.d/pgdg.list"
sudo apt update
sudo apt install postgresql-18 -y
sudo -u postgres psql -c "alter user postgres with password 'postgres'"
sudo sed -i '1ihost    all             all             0.0.0.0/0               md5' /etc/postgresql/18/main/pg_hba.conf
sudo sed -i '1ilocal   all             postgres                                md5' /etc/postgresql/18/main/pg_hba.conf
sudo systemctl restart postgresql
PGPASSWORD=postgres createdb -U postgres testdb

# postgres udfs in python
sudo apt install -y postgresql-plpython3-18 python3-requests

# java
sudo apt install -y maven openjdk-25-jdk-headless
