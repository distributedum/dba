package abd;
import java.sql.*;
import java.util.*;

public class Workload {

    private static final Random random = new Random();
    private static final String randomData = Util.randomString(1000);
    private static final int numSuppliers = 5;

    public static void populate(Random rand, Connection c, int scale) throws Exception {
        List<Util.ProductInfo> productsDataset = Util.getProductsDataset();
        Collections.shuffle(productsDataset);

        // Create schema
        Statement s = c.createStatement();
        s.executeUpdate("drop table if exists client");
        s.executeUpdate("drop table if exists product");
        s.executeUpdate("drop table if exists invoice");
        s.executeUpdate("drop table if exists invoiceLine");
        s.executeUpdate("drop table if exists orders");

        s.executeUpdate("create table client (id int primary key, name varchar, address varchar, data text)");
        s.executeUpdate("create table product (id int primary key, description varchar, price decimal(10, 2), ref varchar, data text, stock int check (stock > 0), min int, max int)");
        s.executeUpdate("create table invoice (id int primary key, clientid int, data text)");
        s.executeUpdate("create table invoiceLine (id serial primary key, invoiceid int, productid int, price decimal(10, 2))");
        s.executeUpdate("create table orders (id serial primary key, productid int, items int, supplier int, data text)");
        s.executeUpdate("create index on invoice (clientid)");
        s.executeUpdate("create index on invoiceLine (invoiceid)");
        s.executeUpdate("create index on orders (supplier)");
        s.executeUpdate("create index on orders (productid)");

        s.close();

        // Insert data
        PreparedStatement insertClient = c.prepareStatement("insert into client values (?, ?, ?, ?)");
        PreparedStatement insertProduct = c.prepareStatement("insert into product values (?, ?, ?, ?, ?, 1050, 1000, 1100)");
        c.setAutoCommit(false); // Autocommit off to execute inserts in a single transaction to reduce overhead
        for (int i = 0; i < Math.pow(2, scale); i++) {
            insertClient.setInt(1, i); // id
            insertClient.setString(2, "client-" + i); // name
            insertClient.setString(3, "address-" + i); // address
            insertClient.setString(4, randomData); // data
            insertClient.addBatch();

            Util.ProductInfo product = productsDataset.get(i % productsDataset.size());
            insertProduct.setInt(1, i); // id
            insertProduct.setString(2, product.name()); // description
            insertProduct.setDouble(3, product.price()); // price
            insertProduct.setString(4, product.ref()); // ref
            insertProduct.setString(5, randomData); // data
            insertProduct.addBatch();
        }
        insertClient.executeBatch();
        insertProduct.executeBatch();
        c.commit(); // commit must be called manually since autocommit is off

        insertClient.close();
        insertProduct.close();
    }


    private final Random rand;
    private final Connection c;
    private final PreparedStatement getProductPrice;
    private final PreparedStatement addInvoice;
    private final PreparedStatement addInvoiceLine;
    private final PreparedStatement updateStock;
    private final PreparedStatement clientProducts;
    private final PreparedStatement topProducts;
    private final PreparedStatement getLowStockProduct;
    private final PreparedStatement addOrder;
    private final PreparedStatement getSupplierOrders;
    private final PreparedStatement deleteSupplierOrders;
    private final int scale;


    public Workload(Random rand, Connection c, int scale) throws Exception {
        this.rand = rand;
        this.c = c;
        this.scale = scale;

        c.setAutoCommit(false); // autocommit = off to execute operations inside a transaction

        // create prepared statements

        getProductPrice = c.prepareStatement("""
            select price
            from product
            where id = ?
        """);

        addInvoice = c.prepareStatement("""
            insert into invoice (id, clientid, data)
            select (select count(*) + 1 from invoice), ?, ?
            returning id
        """);

        addInvoiceLine = c.prepareStatement("""
            insert into invoiceLine (id, invoiceid, productid, price)
            values (default, ?, ?, ?)
        """);

        updateStock = c.prepareStatement("""
            update product
            set stock = stock + ?
            where id = ?
        """);

        clientProducts = c.prepareStatement("""
            select distinct(il.productid)
            from invoice i
            join invoiceLine il on il.invoiceid = i.id
            where i.clientid = ?
        """);

        topProducts = c.prepareStatement("""
            select il.productid, count(i.id)
            from invoice i
            join invoiceLine il on il.invoiceid = i.id
            group by il.productid
            order by count(i.id) desc
            limit 10
        """);

        getLowStockProduct = c.prepareStatement("""
            select p.id, max - stock as unitsToOrder
            from product p
            where stock < min
                and p.id not in (
                    select productid
                    from orders
                )
            order by p.id
            limit 1
            for update
        """);

        addOrder = c.prepareStatement("""
            insert into orders (id, productid, items, supplier, data)
            values (default, ?, ?, ?, ?)
        """);

        getSupplierOrders = c.prepareStatement("""
            select productid, items
            from orders
            where supplier = ?
            order by productid
        """);

        deleteSupplierOrders = c.prepareStatement("""
            delete
            from orders
            where supplier = ?
        """);

        // default isolation = TRANSACTION_READ_COMMITTED
        c.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
    }


    private Set<Integer> randomProductIds(int size) {
        Set<Integer> ids = new HashSet<>();
        while (ids.size() < size) {
            ids.add(rand.nextInt((int) Math.pow(2, scale)));
        }
        return ids;
    }


    private void sell() throws SQLException {
        int clientId = random.nextInt((int) Math.pow(2, scale));

        // invoice
        addInvoice.setInt(1, clientId);
        addInvoice.setString(2, randomData);
        ResultSet rs = addInvoice.executeQuery();
        rs.next();
        int invoiceId = rs.getInt(1);

        // invoice line
        Set<Integer> productIds = randomProductIds(5);
        for (int productId : productIds) {
            // get product price
            getProductPrice.setInt(1, productId);
            rs = getProductPrice.executeQuery();
            rs.next();
            double price = rs.getDouble(1);

            // add new invoice line
            addInvoiceLine.setInt(1, invoiceId);
            addInvoiceLine.setInt(2, productId);
            addInvoiceLine.setDouble(3, price);
            addInvoiceLine.executeUpdate(); // executeUpdate when performing writes

            // update stock
            updateStock.setInt(1, -1);
            updateStock.setInt(2, productId);
            updateStock.executeUpdate();
        }

        c.commit();
    }


    private List<Integer> account() throws SQLException {
        int clientId = random.nextInt((int) Math.pow(2, scale));
        List<Integer> products = new ArrayList<>();
        clientProducts.setInt(1, clientId);
        ResultSet rs = clientProducts.executeQuery(); // executeQuery when performing reads

        while (rs.next()) { // since this returns a cursor, we must use rs.next() to retrieve the data
            products.add(rs.getInt(1));
        }

        return products;
    }


    private Map<Integer, Integer> top10() throws SQLException {
        Map<Integer, Integer> top = new HashMap<>();
        ResultSet rs = topProducts.executeQuery();

        while (rs.next()) {
            top.put(rs.getInt(1), rs.getInt(2));
        }

        return top;
    }


    private void order() throws SQLException {
        ResultSet rs = getLowStockProduct.executeQuery();
        if (!rs.next()) {
            return;
        }

        int productId = rs.getInt(1);
        int unitsToOrder = rs.getInt(2);
        int supplier = rand.nextInt(numSuppliers);

        addOrder.setInt(1, productId);
        addOrder.setInt(2, unitsToOrder);
        addOrder.setInt(3, supplier);
        addOrder.setString(4, randomData);
        addOrder.executeUpdate();

        c.commit();
    }


    private void delivery() throws SQLException {
        int supplier = rand.nextInt(numSuppliers);
        getSupplierOrders.setInt(1, supplier);
        ResultSet rs = getSupplierOrders.executeQuery();

        while (rs.next()) {
            int productId = rs.getInt(1);
            int items = rs.getInt(2);
            updateStock.setInt(1, items);
            updateStock.setInt(2, productId);
            updateStock.executeUpdate();
        }

        deleteSupplierOrders.setInt(1, supplier);
        deleteSupplierOrders.executeUpdate();

        c.commit();
    }


    private TransactionType randomTransactionType() {
        int x = rand.nextInt(100);
        if (x < 75) {
            return TransactionType.Sell;
        } else if (x < 80) {
            return TransactionType.Account;
        } else if (x < 85) {
            return TransactionType.Top10;
        } else if (x < 97) {
            return TransactionType.Order;
        } else {
            return TransactionType.Delivery;
        }
    }


    private TransactionType transactionType = TransactionType.Sell;
    private boolean lastTransactionCompleted = true;

    // we retry the current transactionType until it succeeds
    public void transaction() throws Exception {
        if (lastTransactionCompleted) {
            transactionType = randomTransactionType();
        }

        lastTransactionCompleted = false;
        switch (transactionType) {
            case Sell -> sell();
            case Account -> account();
            case Top10 -> top10();
            case Order -> order();
            case Delivery -> delivery();
        }
        lastTransactionCompleted = true;
    }
}
