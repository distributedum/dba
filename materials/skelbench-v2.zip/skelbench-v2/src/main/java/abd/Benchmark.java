package abd;

import com.beust.jcommander.JCommander;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Random;

public class Benchmark extends Thread {

    private static Options options = new Options();

    private static boolean started, stopped;
    private static int commits, aborts;
    private static long totalRt;

    private static Random rand = new Random();

    public synchronized static void startBench() {
        started = true;

        System.out.println("Started!");
    }

    public synchronized static void logTransaction(long tr, boolean success) {
        if (started && !stopped) {
            if (success) {
                commits++;
                totalRt += tr;
            } else {
                aborts++;
            }
        }
    }

    public synchronized static boolean isStopped() {
        return stopped;
    }

    public synchronized static void stopBench() {
        stopped = true;

        System.out.println("throughput (txn/s) = " + (commits / ((double) options.runtime)));
        System.out.println("response time (s) = " + (totalRt / (commits * 1e9d)));
        System.out.println("abort rate (%) = " + (aborts * 100 / ((double) aborts + commits)));
    }

    public void run() {
        try {
            Connection c = DriverManager.getConnection(options.database, options.user, options.passwd);
            Workload wl = new Workload(rand, c, options.scale);
            while(!isStopped()) {
                long before = System.nanoTime();
                boolean success = true;
                try {
                    wl.transaction();
                } catch(SQLException e) {
                    // check if it is an isolation-related / unique_violation / check_violation exception
                    // make sure other exceptions are shown
                    if (e.getSQLState().startsWith("40") || e.getSQLState().equals("23505") || e.getSQLState().equals("23514")) {
                        try {
                            c.rollback();
                        } catch(Exception e2) { }
                        success = false;
                    } else
                        throw e;
                } finally {
                    long after = System.nanoTime();
                    logTransaction(after - before, success);
                }
            }
            c.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void populate() throws Exception {
        Connection c = DriverManager.getConnection(options.database, options.user, options.passwd);
        Workload.populate(rand, c, options.scale);
        c.close();
    }

    public static void execute() throws Exception {
        Benchmark[] r = new Benchmark[options.clients];
        for(int i=0; i<r.length; i++)
            r[i] = new Benchmark();
        for(int i=0; i<r.length; i++)
            r[i].start();
        Thread.sleep(options.warmup*1000); // aquecimento
        startBench();
        Thread.sleep(options.runtime*1000);  // medidas!!!
        stopBench();
        for(int i=0; i<r.length; i++)
            r[i].join();
    }

    public static void main(String[] args) throws Exception {

        JCommander parser = JCommander.newBuilder()
                .addObject(options)
                .build();
        try {
            parser.parse(args);
            if (options.help) {
                parser.usage();
                return;
            }
        } catch(Exception e) {
            parser.usage();
            return;
        }

        if (options.populate)
            populate();
        if (options.execute)
            execute();
    }

}
