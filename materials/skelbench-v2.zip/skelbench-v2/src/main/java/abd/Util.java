package abd;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.zip.ZipInputStream;

public class Util {

    private static final Random random = new Random();
    private static final char[] chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    private static final String PRODUCT_DATASET_FILE = "products.zip";


    public static String randomString(int n) {
        return IntStream.range(0, n)
                .mapToObj(x -> chars[random.nextInt(chars.length)])
                .map(Object::toString)
                .reduce((acc, x) -> acc + x)
                .get();
    }


    public record ProductInfo (String ref, String name, Double price) {}

    public static List<ProductInfo> getProductsDataset() throws IOException, CsvException {
        List<ProductInfo> result = new ArrayList<>();

        try (var stream = Util.class.getClassLoader().getResourceAsStream(PRODUCT_DATASET_FILE)) {
            var zipStream = new ZipInputStream(stream);
            zipStream.getNextEntry();

            try (CSVReader reader = new CSVReader(new InputStreamReader(zipStream))) {
                reader.readNext();
                List<String[]> rows = reader.readAll();
                for (String[] row : rows) {
                    result.add(new ProductInfo(row[0], row[1], Double.valueOf(row[2])));
                }
            }
        }

        return result;
    }
}
