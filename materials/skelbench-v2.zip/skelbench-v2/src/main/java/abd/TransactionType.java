package abd;

public enum TransactionType {
    Sell,
    Account,
    Top10,
    Order,
    Delivery
}
